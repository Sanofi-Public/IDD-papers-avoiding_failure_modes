from setuptools import setup

setup(
    name='mso',
    version='0.1',
    packages=['mso', 'mso.data', 'mso.objectives'],
    url='',
    license='',
    author='Robin WInter',
    author_email='',
    description='',
    include_package_data=True
)
